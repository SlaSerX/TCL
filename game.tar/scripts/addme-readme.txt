############################################
#####          AddMe !  by Ozh         #####
#####  Pickup game management script   #####
#####  for Eggdrops 1.6.x & TCL 8.3+   #####
############################################

. HISTORY
. LIVE EXAMPLES
. MANUAL
. INSTALLATION & TIPS
. TROUBLESHOOTING & FAQ
. A PROPOS & LICENSE
. FUTURE TODOS ?
. CREDIT


############################################
#
# QUICK WARNING that will save me about 70%
# of queries I get about this script :
# 
# - THIS IS NOT a script for MIRC. It's intented
# to run on eggdrops (or windrops). See website
# http://www.egghelp.org for more info. I have
# no idea of where to get something similar
# for mIRC, and I wont code it for mIRC.
#
# - I CANT GIVE YOU AN EGGDROP nor lend mine
# for your pickup channel.
# You'll have to have someone lend or rent
# you a shell or an eggdrop. Same site as above
# for infos.
#
############################################


HISTORY
############################################

2.00 - February-April 2003
  . !promote
  . !stats
  . !motd
  . optionnal autoremoveall
  . optionnal autoswitch game server
  . map & server list, managed from irc
  . better help functions and messages
  . lots of options, on a channel basis
  . looots of code cleanup
  . lessss regular expression, for better compatibility
  with TCL version I believe
  . from 400 to 1600 lines of code :>

1.01 - March 2002
  . very minor (but highly requested) new feature :
  !server to change server's IP & pass
  . a few useless cleanings in code

1.00 - July 2001 or somewhen :P
  first release	(and, as far as I know, first TCL
  script of its kind)


LIVE EXAMPLES
############################################

Before getting started, you may want to see live
examples of the script running
Currently (feb 2003) you can find several
channels on Quakenet (irc.quakenet.org) running this
script the main one being #ctfpickup.fr (200+ people
when night comes, 2000 pickups a month)


MANUAL
############################################

If you have no clue about what is a pickup game
(why the hell did you get this script for then ? :)
I suggest you read the following section.

Then, or if you already know what is a pickup
game, I suggest you read the script itself : it's
heavily commented, and will explain how things
work and happen.
Read the script even if you dont want to modify
it, or even if you dont understand TCL language
(read only the comments, of course :)


MANUAL, I SAID !
############################################

A pickup game is : X players join a server, 2 of
them are captains, and pick one player in their
team after each other. Once the two teams are
formed, they play :)

This TCL script is used to manage a channel topic
where you want to organise pickup games.
For example, you need a given number of players
to play <!-- insert any game name here --> and wish
to allow anyone on the channel to register on a list.

You can have the bot to sit in multiple channels
and manage one or more topics without getting
messy stuff.

Players who want to fill in an available slot (a dot
in topic) use public message commands : !addme
To leave list, they type : !removeme

As soon as the players list gets full, the bot warns
every registered player with a private notice.

When a game starts, and if you set it to do so, the bot
can pick 2 players from the topic list (eg team captains),
and pick a given number of maps from a map list (force
players to play a map, or to chose from a short list)

When the topic gets full, and if you set it to do it, the
bot can automatically clear players list, so that other
gamers can type !add asap.

If some of them are late, and topic isnt automatically
cleared, you can recall everyone in the list : !recall

If you wish, when topic gets cleared (either automatically
by the bot, or manually by you with !removeall) the server
mentionned in topic can automatically be changed from
a given server list : useful if you have at least 2 dedicated
servers and when topic gets completed fast on populated
channels, so players wont join a server where a game is going on.

Map list and server list mentionned above are managed
directly from irc, with /msg commands, and are persistant
and written to disk
If the bot dies or quits, map and server lists will be
read from disk so you dont need to redo list from scratch,
nor write them directly into script.

When a player joins the IRC channel, the bot greets
him with a message of your choice. 
At any moment one can be messaged the help : !help
The help message will vary, depending on if the requester
is an op or not (public / admin commands)

Every command (except !addme and !removeme) can be assigned
to ops only, or be public commands.

Topic will always have this form :
 Next : <player list> | Server : <server ip> | <motd>
For example :
 Next : Player1/Dude2/Nick3/././. | Server : 127.0.0.1:27910 pass toto | This is a good day to frag

If the topic gets to some other form, the bot wont understand
If you're too confused, delete the topic and type !removeall
to get a clean new one.


INSTALLATION & TIPS
############################################

Configure the script : at the very beginning of the script,
you have to modify several lines.
Each variable you need to modify is commented inline, and
a suggested value is mentionned.
Edit the script with a raw text editor, on Windows your
Notepad will do fine. DONT USE WORDPAD OR WORD

Upload the script : put it in your eggdrop's script directory,
something like /home/you/eggdrop/scripts/

At the end of your bot's configuration file (eggdrop.conf),
add this line : source scripts/addme.tcl

In the middle of your eggdrop.conf, dont forget to add
pickup channels if not already done : mentionning
channels in the script wont make the bot join them :)

To have the bot load the script, .rehash or .restart
the bot. Once it has joined your pickup channel(s),
ERASE TOPIC AND TYPE !REMOVEALL.
Please read the above sentence twice, as it will
save me another 50% of queries I get :>

Make sure your bot is and will always be opped in
channels, otherwise it wont be able to change topic,
and some admin commands reserved to ops may not work.
There are several scripts around to auth your bot
on a network service. For example, concerning Q or L
on Quakenet, go to www.egghelp.org/tcl.shtml
and look for "auth Q"

Another good idea is enforcing +t mode in pickup
channels, to prevent players from modifying topic
by accident, and thus breaking it :) (botwise, I
mean :)

Once your bot sits in your pickup channel, type
!help and play around with admin commands to
populate map and/or server lists (if you wish
to use this feature)

This scripts works nice with QStats for Eggdrop,
which will allow players to retrieve stats
from game servers directly from within IRC.
To get this script, head to www.egghelp.org/tcl.shtml
and look for 'qstat' in the search form.


TROUBLESHOOTING & FAQ
############################################

This script and its previous versions have been
around for a few months, here are the questions
I've been queried about

Q : How do I load the script ?
A : Add "source scripts/addme.tcl" at the end of
your eggdrop.conf file and restart or rehash the
bot

Q : egdropt.conf file ??? Is it another script I
have to load in mIRC ??
A : Put your fingers into a plug and ask for some
water on the ground around you.

Q : I've edited the script but the bot crashes
when I try to load it !!!1
A : Use a raw text editor, like Notepad on
Windows or pico on Linux. DONT use something like
Wordpad on Windows.

Q : I've edited the script and loaded it, but I
have an error when I try to [add or change ip or
anything] which says : "Tcl error [addme_something]:
can't read "tmp": no such variable"
A : Erase topic, clear topic, empty topic, rm -f topic,
type !removeall so the bot creates a new clean topic
with a valid structure, then !add or !ip or anything.

Q : There's a bug, it's not working.
A : Wrong, you modified it and now it's not working.
I've tested it on eggdrops and windrops 1.6.4 and
1.6.13, with TCL 8.3.3 and 8.4.2 successfully. If
you *just* edit as required the beginning of the
script and run it, it does work. Ok ? ;)


A PROPOS & LICENSE
############################################

This script is made from scratch, although the
idea was stolen from Echinus and his Echbot
on Quakenet. But his bot is written in Perl,
and I wanted to use TCL, so I did this one :)

It was designed with Quake pickup games in
mind, but could actually be used for really
any online multiplayer game. I've been contacted
by players from various games : HL / CS, UT, even
Worms :)

I didnt make this script to compete with Echbot
nor try to take its place on Quakenet :)
Echbot is a very good and fast bot. But you cant
tweak things on it nor modify the script.
My script requires an eggdrop, which may be
difficult to get for free, but you manage
everything in it, it's your bot & your script.

I did this script because it was a little
challenge for me, and it was my TCL learning
experiment :)
I must say I'm pretty satisfied with it now,
and I can say that TCL is definitely a crap
language :>

This script is distributed without any warranty.
It's fully open source, you can modify to suit your
needs. After all, the bits of TCL I've learned
come from others' script, so I'll be glad if
you learn things from mine :)
If you modify this script and distribute it, please
include the original version & this readme so
users after you can understand where it comes from
and think I'm the coolest guy on earth.

If you modify this script and / or add something
valuable to it, I'll be glad to hear from you.

Please do not mirror this file & script, as it will
not be kept up to date if I write a new version.
Latest version will always be available at Slennox's
www.egghelp.org


FUTURE TODOS ?
############################################

I probably wont update this script, unless someone
tells me there is an utter uber ultra important
new feature I could add :)

The only improvement I can think about at the
moment is the ability of managing every setting
from IRC, i.e. not editing the beginning of
the script but setting everything from IRC once
the bot is running. Maybe I'll do it one day.

I didnt want to add every feature I could
think about or people suggested me, like managing
temporary bans for people who wont join servers,
automatically scanning a game server when
its ip is used in topic, etc...

There are lots of scripts around to do these
things, use them if you want them. I just scripted
what is strictly related to organise pickup games,
the rest is up to you :)

I've been requested to add timers into this
script, that would for example autoclear players list
when it's not been updated for a while, to ensure
all players listed are still here and not gone sleeping :)
I didnt implement this, because it would have completely
gone shit if the bot crashes, or if there is a netsplit,
making the bot leave a pickup channel and come back
a while later. The bot would have lost track of timers.
Plus, timers in TCL suck biiiiig time :)


CREDITS
############################################

Thanks to Slennox from egghelp.org for his
excellent website and for hosting the file.

Thanks to Echinus who have inspired me this
script, with his very efficient perl bot Echbot.

Thanks to players in #ctfpickup.fr who have
sent me ideas and feature requests :)


Ozh,
ozh@planetquake.com
http://FrenchFragFactory.net
Ozh on #SARL on Quakenet (irc.quakenet.org)