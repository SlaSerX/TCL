#!/bin/bash

scripts/sysinfo281.19.pl 2>/dev/null
